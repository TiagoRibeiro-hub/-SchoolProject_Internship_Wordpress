<?php

//Menu
function register_nav(){
    register_nav_menus(
        array(
            'header' => 'Header'
        )
    );

    register_nav_menus(
        array(
            'footer' => 'Footer'
        )
    );

    register_nav_menus(
        array(
            '404' => '404'
        )
    );
}

// Stylesheets & JS
function load_stylesheets()
{
    // wp_register_style('fontawesome', get_template_directory_uri().'/fontawesome/css/all.css', array(), false, 'all');
    // wp_enqueue_style('fontawesome');

    // wp_register_style('bootstrap', get_template_directory_uri().'/css/bootstrap.min.css', array(), false, 'all');
    // wp_enqueue_style('bootstrap');

    wp_register_style('stylesheets', get_template_directory_uri().'/css/my-css.css', array(), false, 'all');
    wp_enqueue_style('stylesheets');
}
add_action('wp_enqueue_scripts', 'load_stylesheets');

function load_jquery(){
    
    wp_deregister_script('jquery');
    wp_enqueue_script('jquery', get_template_directory_uri().'/js/jquery-3.1.3.min.js', '', 1, true);
}
add_action('wp_enqueue_scripts', 'load_jquery');

function load_js(){

    wp_register_script('bootstrap_Js', get_template_directory_uri().'/js/bootstrap.bundle.min.js', '', 1, true);
    wp_enqueue_script('bootstrap_Js');

    wp_register_script('custom_Js', get_template_directory_uri().'/js/scripts.js', '', 1, true);
    wp_enqueue_script('custom_Js');
}
add_action('wp_enqueue_scripts', 'load_js');


// Theme Options 
add_theme_support('menus');
add_theme_support('post-thumbnails');
add_theme_support('widgets');


// Size Images
@ini_set( 'upload_max_size' , '256M' );
@ini_set( 'post_max_size', '256M');
@ini_set( 'max_execution_time', '400' );

// add_image_size('smallest', 475, 475, array('center', 'center'));
// add_image_size('largest', 800, 800, array('center', 'center'));

// Register Sidebars
function my_sidebars()
{
    register_sidebar(
        array(
            'name' => 'Page Sidebar',
            'id' => 'page-sidebar',
            'before_title' => '<h4 class="widget-title>',
            'after_title' => '</h4',

        )
    );
}
add_action('widgets_init', 'my_sidebars');


// ACTION FIELD TEAM
if( function_exists('acf_add_local_field_group') ):

	acf_add_local_field_group(array(
		'key' => 'group_6114ef9ba0b1f',
		'title' => 'Team',
		'fields' => array(
			array(
				'key' => 'field_6115247ccba99',
				'label' => 'Job',
				'name' => 'job',
				'type' => 'text',
				'instructions' => '',
				'required' => 1,
				'conditional_logic' => 0,
				'wrapper' => array(
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'maxlength' => '',
			),
			array(
				'key' => 'field_6114efb7bee8d',
				'label' => 'Email Address',
				'name' => 'email_address',
				'type' => 'email',
				'instructions' => '',
				'required' => 1,
				'conditional_logic' => 0,
				'wrapper' => array(
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
			),
			array(
				'key' => 'field_6114efeabee8e',
				'label' => 'Phone Number',
				'name' => 'phone_number',
				'type' => 'text',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array(
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'maxlength' => '',
			),
			array(
				'key' => 'field_6115007b5650a',
				'label' => 'About Me',
				'name' => 'about_me',
				'type' => 'wysiwyg',
				'instructions' => '',
				'required' => 1,
				'conditional_logic' => 0,
				'wrapper' => array(
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'tabs' => 'all',
				'toolbar' => 'full',
				'media_upload' => 1,
				'delay' => 0,
			),
			array(
				'key' => 'field_6114f00abee8f',
				'label' => 'Areas of Interest',
				'name' => 'areas_of_interest',
				'type' => 'wysiwyg',
				'instructions' => '',
				'required' => 1,
				'conditional_logic' => 0,
				'wrapper' => array(
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'tabs' => 'all',
				'toolbar' => 'full',
				'media_upload' => 1,
				'delay' => 0,
			),
		),
		'location' => array(
			array(
				array(
					'param' => 'post_type',
					'operator' => '==',
					'value' => 'team',
				),
			),
		),
		'menu_order' => 0,
		'position' => 'normal',
		'style' => 'default',
		'label_placement' => 'top',
		'instruction_placement' => 'label',
		'hide_on_screen' => '',
		'active' => true,
		'description' => '',
	));
	
endif;

require_once('shortcodes/team.php');
require_once('shortcodes/random-team-member.php');

/**
 * This example shows how to add several tabs with custom shortcodes into the Profile page of the Ultimate Member.
 * You can add custom code to the end of the file functions.php in the active theme directory.
 * Important! Each tab must have a unique key.
 * 
 * Ultimate Member documentation: https://docs.ultimatemember.com/
 * Ultimate Member support (for customers): https://ultimatemember.com/support/ticket/
 * 
 * ICONS -> https://gist.github.com/plusplugins/b504b6851cb3a8a6166585073f3110dd
 */
 

/**
 * Add new profile tabs
 * @param  array $tabs
 * @return array
 */
function um_mycustomtab_add_tab( $tabs ) {

	/* Create a post */

	$tabs['create_a_post'] = array(
		'name'            => 'Create a Post',
		'icon'            => 'um-faicon-pencil',
		'custom'          => true
	);

	if ( !isset( UM()->options()->options['profile_tab_' . 'create_a_post'] ) ) {
		UM()->options()->update( 'profile_tab_' . 'create_a_post', true );
	}

	/* Read All Post */

	$tabs['read_all_post'] = array(
		'name'            => 'Read All Post',
		'icon'            => 'um-icon-android-folder-open',
		'custom'          => true
	);

	if ( !isset( UM()->options()->options['profile_tab_' . 'read_all_post'] ) ) {
		UM()->options()->update( 'profile_tab_' . 'read_all_post', true );
	}

	/* Video */

	$tabs['video'] = array(
		'name'            => 'Video',
		'icon'            => 'um-icon-ios-videocam',
		'custom'          => true
	);

	if ( !isset( UM()->options()->options['profile_tab_' . 'video'] ) ) {
		UM()->options()->update( 'profile_tab_' . 'video', true );
	}

	return $tabs;
}
add_filter( 'um_profile_tabs', 'um_mycustomtab_add_tab', 1000 );


/**
 * Render the tab 'Create a post'
 * @param array $args
 */
function um_profile_content_create_a_post( $args ) {
	if (function_exists('user_submitted_posts')) user_submitted_posts();
}
add_action( 'um_profile_content_create_a_post', 'um_profile_content_create_a_post' );

/**
 * Render the tab 'Read All Post'
 * @param array $args
 */
function um_profile_content_read_all_post( $args ) {
	?>
		<h1 class="text-center">Clik the link and enjoy the post</h1>
	<?php
	if (function_exists('usp_display_posts')) echo usp_display_posts(array('userid' => 'all', 'numposts' => -1));
}
add_action( 'um_profile_content_read_all_post', 'um_profile_content_read_all_post' );

/**
 * Render the tab 'Video'
 * @param array $args
 */
function um_profile_content_video( $args ) {
	//colocar content
}
add_action( 'um_profile_content_video', 'um_profile_content_video' );
 





