<?php

function contact_form(){

}

add_shortcode('contact-form', 'contact_form');