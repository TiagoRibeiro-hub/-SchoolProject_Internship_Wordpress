<!-- Pagina relativa ao posts -->

<?php get_header();?>

<?php get_template_part('includes/section','content'); ?>

<?php get_footer();?>