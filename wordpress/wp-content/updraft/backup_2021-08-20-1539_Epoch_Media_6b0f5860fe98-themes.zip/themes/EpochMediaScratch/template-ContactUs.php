<?php
/*
Template Name: Contact Us
*/
?>

<?php get_header();?>

<?php get_template_part('includes/section','content'); ?>

<?php get_footer();?>