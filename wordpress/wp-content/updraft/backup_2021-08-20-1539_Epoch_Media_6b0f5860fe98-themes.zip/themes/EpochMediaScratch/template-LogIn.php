<?php
/*
Template Name: LogIn
*/
?>

<?php get_header();?>

<div class="d-flex justify-content-center align-content-center logInBox" style="margin-top:70px">
    <div class="card text-center cardMine" style="width:600px">
        <div class="card-header bg-transparent cardMine">
            <h3>
                Welcome
            </h3>
        </div>
        <div class="card-body cardMine">
            <div class="d-flex justify-content-center">
                <input type="email" id="email" class="form-control mt-3 inputMine" placeholder="E-mail" required autofocus />
            </div>
            <div class="d-flex justify-content-center">
                <input type="password" id="password" class="form-control mt-3 inputMine" placeholder="Password" />
            </div>
            <div class="d-flex justify-content-center">
                <input type="password" id="confirmPassword" class="form-control mt-3 inputMine" placeholder="Confirm Password" />
            </div>
            <div class="checkbox mt-3 text-center">
                <label>
                    <input type="checkbox" id="rememberMe" value="remember-me" />Remember me
                </label>
            </div>
        </div>
        <div class="card-footer bg-transparent cardMine">
            <button class="btn btnMine" id="btnLogIn" type="submit">Log In</button>
        </div>
    </div>
</div>


<?php get_footer();?>
