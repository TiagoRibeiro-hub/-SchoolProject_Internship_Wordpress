<?php
/*
Template Name: Register
*/
?>

<?php get_header();?>

<div class="d-flex justify-content-center align-content-center" style="margin-top:70px">
    <div class="card text-center cardMine" style="width:1000px">
        <div class="card-header bg-transparent cardMine">
            <h3>
                Register
            </h3>
        </div>
        <div class="card-body cardMine">
            <div class="d-flex justify-content-center">
                <input type="text" id="userName" class="form-control m-3 inputMine inputMineRegister" placeholder="User Name" required autofocus />
                <input type="text" id="birthdate" class="form-control m-3 inputMine inputMineRegister" placeholder="Birthdate" onfocus="datePickerFuncs()" onblur="dateTextFuncs()"/>
            </div>
            <div class="d-flex justify-content-center">
                <input type="text" id="address" class="form-control m-3 inputMine inputMineRegister" placeholder="Address" />
            </div>
            <div class="d-flex justify-content-center">
                <input type="text" id="postalCode" class="form-control m-3 inputMine inputMineRegister" placeholder="Postal Code" />
                <input type="text" id="location" class="form-control m-3 inputMine inputMineRegister" placeholder="Location" />
            </div>
            <div class="d-flex justify-content-center">
                <input type="email" id="email" class="form-control m-3 inputMine inputMineRegister" placeholder="E-mail" />
                <input type="email" id="confirmEmail" class="form-control m-3 inputMine inputMineRegister" placeholder="Confirm E-mail" />
            </div>
            <div class="d-flex justify-content-center">
                <input type="password" id="password" class="form-control m-3 inputMine inputMineRegister" placeholder="Password" />
                <input type="password" id="confirmPassword" class="form-control m-3 inputMine inputMineRegister" placeholder="Confirm Password" />
            </div>
        </div>
        <div class="card-footer bg-transparent cardMine">
            <button class="btn btnMine" id="btnRegister" type="submit">Register</button>
        </div>
    </div>
</div>




<?php get_footer();?>

<script>
    function datePickerFuncs() {
    document.getElementById("birthdate").type = "date";
}

function dateTextFuncs() {
    document.getElementById("birthdate").type = "text";
}
</script>